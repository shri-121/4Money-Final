import axios from 'axios';

const BASE = process.env.REACT_APP_BACKEND_URL || '';

const api = axios.create({ baseURL: `${BASE}/api` });

api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('4m_token') || localStorage.getItem('4m_admin_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

api.interceptors.response.use(
  r => r,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('4m_token');
      localStorage.removeItem('4m_admin_token');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;
