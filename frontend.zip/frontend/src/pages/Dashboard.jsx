import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import api from '../api';

// ── Icons (inline SVG) ────────────────────────────────────────────────────────
const Icon = ({ d, size = 20, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

// ── Small Components ──────────────────────────────────────────────────────────
const Logo = () => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
    <div style={{ width: 32, height: 32, background: '#E8590C', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>💰</div>
    <span style={{ fontWeight: 800, fontSize: 18 }}>4Money</span>
  </div>
);

const StatCard = ({ label, value, sub, bg = '#fff', valueColor = '#1a1a1a' }) => (
  <div style={{ background: bg, borderRadius: 16, padding: 18, flex: 1, border: '1px solid #eee', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
    <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: '#aaa', marginBottom: 6 }}>{label}</div>
    <div style={{ fontWeight: 800, fontSize: 22, color: valueColor }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: '#aaa', marginTop: 3 }}>{sub}</div>}
  </div>
);

const TxRow = ({ tx }) => {
  const isDeposit = tx.kind === 'deposit';
  const status = tx.status;
  const badgeStyle = {
    approved: { background: '#e8f5e9', color: '#2e7d32' },
    rejected: { background: '#fdecea', color: '#c62828' },
    pending:  { background: '#fffde7', color: '#f57f17' },
  }[status] || { background: '#f5f5f5', color: '#888' };

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', borderBottom: '1px solid #f5f5f5' }}>
      <div style={{ width: 42, height: 42, borderRadius: 12, background: isDeposit ? '#fdf0e8' : '#e8f5e9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>
        {isDeposit ? '⬇️' : '⬆️'}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: 14 }}>{isDeposit ? 'USDT Deposit' : 'Withdrawal'}</div>
        <div style={{ fontSize: 12, color: '#aaa', marginTop: 2 }}>{new Date(tx.created_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontWeight: 700, fontSize: 14, color: isDeposit ? '#E8590C' : '#555' }}>
          {isDeposit ? `+${tx.sc_amount} SC` : `-${tx.sc_amount} SC`}
        </div>
        <div style={{ ...badgeStyle, borderRadius: 20, padding: '2px 8px', fontSize: 10, fontWeight: 700, marginTop: 3, display: 'inline-block' }}>
          {status?.toUpperCase()}
        </div>
      </div>
    </div>
  );
};

// ── Main Dashboard ────────────────────────────────────────────────────────────
export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser]           = useState(null);
  const [tab, setTab]             = useState('home');
  const [transactions, setTx]     = useState([]);
  const [loading, setLoading]     = useState(false);

  // Deposit state
  const [depStep, setDepStep]     = useState(1);
  const [depUsdt, setDepUsdt]     = useState('');
  const [depId, setDepId]         = useState('');
  const [depScAmount, setDepSc]   = useState(0);
  const [depWallet, setDepWallet] = useState('');
  const [depOtp, setDepOtp]       = useState('');
  const [depTxId, setDepTxId]     = useState('');
  const [depSS, setDepSS]         = useState('');
  const [depDevOtp, setDepDevOtp] = useState('');

  // Withdraw state
  const [wdAmount, setWdAmount]   = useState('');
  const [upiId, setUpiId]         = useState('');
  const [phone, setPhone]         = useState('');

  const [err, setErr]             = useState('');
  const [msg, setMsg]             = useState('');

  const loadUser = useCallback(async () => {
    try {
      const r = await api.get('/auth/me');
      setUser(r.data);
    } catch { navigate('/login'); }
  }, [navigate]);

  const loadTx = useCallback(async () => {
    try {
      const r = await api.get('/user/transactions');
      setTx(r.data.transactions || []);
    } catch {}
  }, []);

  useEffect(() => { loadUser(); loadTx(); }, [loadUser, loadTx]);

  const go = async (fn) => {
    setErr(''); setMsg(''); setLoading(true);
    try { await fn(); }
    catch (e) { setErr(e.response?.data?.detail || 'Something went wrong.'); }
    finally { setLoading(false); }
  };

  const logout = () => {
    localStorage.removeItem('4m_token');
    localStorage.removeItem('4m_user');
    navigate('/login');
  };

  const copyText = (text, label) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied!`);
  };

  // ── Deposit Handlers ───────────────────────────────────────────────────────
  const initiateDeposit = () => go(async () => {
    if (!depUsdt || parseFloat(depUsdt) <= 0) { setErr('Enter valid USDT amount.'); return; }
    const r = await api.post('/deposit/initiate', { usdt_amount: parseFloat(depUsdt) });
    setDepId(r.data.deposit_id);
    setDepSc(r.data.sc_amount);
    if (r.data.dev_otp) { setDepDevOtp(r.data.dev_otp); toast.info(`Dev OTP: ${r.data.dev_otp}`); }
    else toast.success('OTP sent to your email!');
    setDepStep(2);
  });

  const verifyDepositOtp = () => go(async () => {
    const r = await api.post('/deposit/verify-otp', { deposit_id: depId, otp_code: depOtp });
    setDepWallet(r.data.wallet_address);
    toast.success('OTP verified! Now send USDT to the address shown.');
    setDepStep(3);
  });

  const handleSSUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setErr('Screenshot must be under 5MB.'); return; }
    const reader = new FileReader();
    reader.onload = () => setDepSS(reader.result);
    reader.readAsDataURL(file);
  };

  const submitProof = () => go(async () => {
    if (!depTxId) { setErr('Enter transaction ID.'); return; }
    if (!depSS) { setErr('Upload screenshot.'); return; }
    await api.post('/deposit/submit-proof', {
      deposit_id: depId, transaction_id: depTxId, screenshot_base64: depSS
    });
    toast.success('Proof submitted! Admin will review within 30 minutes. ✅');
    resetDeposit(); setTab('activity'); loadTx();
  });

  const resetDeposit = () => {
    setDepStep(1); setDepUsdt(''); setDepId(''); setDepSc(0);
    setDepWallet(''); setDepOtp(''); setDepTxId(''); setDepSS(''); setDepDevOtp('');
    setErr(''); setMsg('');
  };

  // ── Withdraw Handler ───────────────────────────────────────────────────────
  const saveUpi = () => go(async () => {
    await api.post('/user/update-upi', { upi_id: upiId, phone });
    toast.success('UPI ID saved!');
    loadUser();
  });

  const requestWithdrawal = () => go(async () => {
    const amt = parseFloat(wdAmount);
    if (!amt || amt < 1000) { setErr('Minimum withdrawal is 1,000 SCoins.'); return; }
    if (!user?.upi_id) { setErr('Please save your UPI ID first.'); return; }
    await api.post('/withdraw/request', { sc_amount: amt });
    toast.success('Withdrawal request submitted! Processing within 24 hours. ✅');
    setWdAmount(''); loadUser(); loadTx();
  });

  if (!user) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
      <span className="spinner" style={{ borderTopColor: '#E8590C', borderColor: '#eee', width: 32, height: 32 }} />
    </div>
  );

  const scoins = user.scoins || 0;
  const inrVal = scoins.toFixed(2);
  const usdtVal = (scoins / 106.4).toFixed(2);

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="page">

      {/* ── HOME TAB ─────────────────────────────────────────────────────── */}
      {tab === 'home' && (
        <div className="page-pad">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
            <Logo />
            <button onClick={logout} style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>Logout</button>
          </div>

          {/* Balance card */}
          <div style={{ background: 'linear-gradient(135deg, #E8590C, #ff8c42)', borderRadius: 20, padding: 24, marginBottom: 16, color: '#fff' }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, opacity: 0.8, marginBottom: 4 }}>SCOIN BALANCE</div>
            <div style={{ fontWeight: 800, fontSize: 40, lineHeight: 1.1 }}>
              {scoins.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              <span style={{ fontSize: 18, fontWeight: 600, opacity: 0.8, marginLeft: 6 }}>SC</span>
            </div>
            <div style={{ display: 'flex', gap: 16, marginTop: 16 }}>
              <div style={{ background: 'rgba(255,255,255,0.15)', borderRadius: 10, padding: '10px 14px', flex: 1 }}>
                <div style={{ fontSize: 10, opacity: 0.7, fontWeight: 600, letterSpacing: 1 }}>INR VALUE</div>
                <div style={{ fontWeight: 700, fontSize: 16, marginTop: 2 }}>₹{inrVal}</div>
              </div>
              <div style={{ background: 'rgba(255,255,255,0.15)', borderRadius: 10, padding: '10px 14px', flex: 1 }}>
                <div style={{ fontSize: 10, opacity: 0.7, fontWeight: 600, letterSpacing: 1 }}>USDT VALUE</div>
                <div style={{ fontWeight: 700, fontSize: 16, marginTop: 2 }}>${usdtVal}</div>
              </div>
            </div>
          </div>

          {/* Rate info */}
          <div style={{ background: '#fdf5eb', borderRadius: 12, padding: '10px 16px', marginBottom: 20, fontSize: 13, color: '#8a5500' }}>
            ℹ️ Exchange rate: 1 USDT = 106.4 SCoins &nbsp;|&nbsp; 1 SCoin = ₹1 INR
          </div>

          {/* Quick actions */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 24 }}>
            {[
              { label: 'ADD FUNDS', icon: '➕', bg: '#E8590C', color: '#fff', action: () => setTab('deposit') },
              { label: 'WITHDRAW', icon: '🏛️', bg: '#f5f5f5', color: '#555', action: () => setTab('withdraw') },
              { label: 'ACTIVITY', icon: '📋', bg: '#f5f5f5', color: '#555', action: () => setTab('activity') },
            ].map(b => (
              <button key={b.label} onClick={b.action} style={{
                flex: 1, background: b.bg, color: b.color, border: 'none',
                borderRadius: 14, padding: '14px 8px', cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6
              }}>
                <span style={{ fontSize: 22 }}>{b.icon}</span>
                <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: 1 }}>{b.label}</span>
              </button>
            ))}
          </div>

          {/* Invite code */}
          <div style={{ background: '#1a1a1a', borderRadius: 16, padding: 20, marginBottom: 20, color: '#fff' }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: '#888', marginBottom: 8 }}>YOUR REFERRAL CODE</div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontWeight: 800, fontSize: 28, letterSpacing: 4, color: '#E8590C' }}>{user.invite_code}</span>
              <button onClick={() => copyText(user.invite_code, 'Invite code')} style={{
                background: '#333', border: 'none', color: '#fff', padding: '8px 16px',
                borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 600
              }}>Copy</button>
            </div>
            <div style={{ fontSize: 12, color: '#666', marginTop: 6 }}>Share to earn +106.4 SCoins per referral</div>
          </div>

          {/* Recent transactions */}
          <div style={{ marginBottom: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontWeight: 700, fontSize: 17 }}>Recent Activity</h3>
            <button onClick={() => setTab('activity')} style={{ color: '#E8590C', background: 'none', border: 'none', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>View All ›</button>
          </div>
          {transactions.length === 0
            ? <div style={{ textAlign: 'center', color: '#ccc', padding: 24, fontSize: 14 }}>No transactions yet. Make your first deposit! 🚀</div>
            : transactions.slice(0, 3).map((tx, i) => <TxRow key={i} tx={tx} />)
          }
        </div>
      )}

      {/* ── DEPOSIT TAB ──────────────────────────────────────────────────── */}
      {tab === 'deposit' && (
        <div className="page-pad">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
            <button onClick={() => { resetDeposit(); setTab('home'); }} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#555' }}>←</button>
            <h2 style={{ fontWeight: 800, fontSize: 22, flex: 1 }}>Deposit USDT</h2>
            <span style={{ background: '#fdf0e8', color: '#E8590C', padding: '4px 12px', borderRadius: 20, fontSize: 11, fontWeight: 700, letterSpacing: 1 }}>TRC20</span>
          </div>

          {/* Conversion info */}
          <div style={{ background: '#1a1a1a', borderRadius: 16, padding: 20, marginBottom: 24, borderLeft: '4px solid #E8590C' }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: '#666', marginBottom: 10 }}>LIVE CONVERSION RATE</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 24, color: '#fff' }}>1 USDT</div>
                <div style={{ fontSize: 12, color: '#666' }}>Deposit</div>
              </div>
              <span style={{ color: '#E8590C', fontSize: 20, fontWeight: 700 }}>→</span>
              <div>
                <div style={{ fontWeight: 800, fontSize: 24, color: '#E8590C' }}>106.4 SC</div>
                <div style={{ fontSize: 12, color: '#666' }}>SCoins Credit</div>
              </div>
            </div>
            <div style={{ marginTop: 10, fontSize: 12, color: '#555' }}>1 SCoin = ₹1 INR (Fixed)</div>
          </div>

          {/* Step indicator */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
            {['Amount', 'Verify OTP', 'Send & Proof'].map((s, i) => (
              <div key={s} style={{ flex: 1 }}>
                <div style={{ height: 3, borderRadius: 2, background: i + 1 <= depStep ? '#E8590C' : '#eee', marginBottom: 4 }} />
                <div style={{ fontSize: 10, fontWeight: 700, color: i + 1 <= depStep ? '#E8590C' : '#ccc' }}>{s}</div>
              </div>
            ))}
          </div>

          {err && <div className="error-box">{err}</div>}

          {/* Step 1 */}
          {depStep === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <label className="label">USDT Amount (Min: 5 USDT)</label>
                <input className="input" type="number" placeholder="e.g. 100" min="5"
                  value={depUsdt} onChange={e => setDepUsdt(e.target.value)}
                  style={{ fontSize: 20, fontWeight: 700 }} />
                {depUsdt > 0 && (
                  <div style={{ background: '#fdf0e8', borderRadius: 10, padding: '10px 14px', marginTop: 8 }}>
                    <span style={{ fontSize: 13, color: '#8a5500' }}>You will receive: </span>
                    <strong style={{ color: '#E8590C', fontSize: 16 }}>{(parseFloat(depUsdt) * 106.4).toFixed(2)} SCoins</strong>
                    <span style={{ fontSize: 12, color: '#aaa', marginLeft: 6 }}>(≈ ₹{(parseFloat(depUsdt) * 106.4).toFixed(2)})</span>
                  </div>
                )}
              </div>
              <button className="btn-orange" onClick={initiateDeposit} disabled={!depUsdt || loading}>
                {loading ? <span className="spinner" /> : 'Continue & Get OTP →'}
              </button>
            </div>
          )}

          {/* Step 2 */}
          {depStep === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ background: '#fff8e1', border: '1px solid #ffc107', borderRadius: 12, padding: 16, textAlign: 'center' }}>
                <div style={{ fontSize: 13, color: '#7a5c00', marginBottom: 6 }}>OTP sent to <strong>{user.email}</strong></div>
                {depDevOtp && <div style={{ fontWeight: 800, fontSize: 28, color: '#E8590C', letterSpacing: 6 }}>{depDevOtp}</div>}
              </div>
              <div>
                <label className="label">Enter 6-Digit OTP</label>
                <input className="input" type="text" placeholder="000000" maxLength={6}
                  value={depOtp} onChange={e => setDepOtp(e.target.value.replace(/\D/g, ''))}
                  style={{ fontSize: 24, fontWeight: 700, letterSpacing: 8, textAlign: 'center' }} />
              </div>
              <button className="btn-orange" onClick={verifyDepositOtp} disabled={depOtp.length !== 6 || loading}>
                {loading ? <span className="spinner" /> : 'Verify OTP →'}
              </button>
              <button className="btn-ghost" onClick={() => setDepStep(1)}>← Back</button>
            </div>
          )}

          {/* Step 3 */}
          {depStep === 3 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ background: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: 14, padding: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#0369a1', marginBottom: 8 }}>
                  Send exactly <strong>{depUsdt} USDT</strong> to this TRC20 address:
                </div>
                <div style={{ background: '#fff', borderRadius: 10, padding: '12px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontFamily: 'monospace', fontSize: 13, wordBreak: 'break-all', color: '#333' }}>{depWallet}</span>
                  <button onClick={() => copyText(depWallet, 'Wallet address')} style={{ background: '#E8590C', color: '#fff', border: 'none', borderRadius: 8, padding: '6px 12px', cursor: 'pointer', fontSize: 12, fontWeight: 700, whiteSpace: 'nowrap' }}>Copy</button>
                </div>
                <div style={{ marginTop: 10, fontSize: 12, color: '#e11d48', fontWeight: 600 }}>
                  ⚠️ Only send via TRC20 network. Other networks = permanent loss of funds.
                </div>
              </div>

              <div>
                <label className="label">Transaction Hash / ID</label>
                <input className="input" placeholder="Enter blockchain transaction ID"
                  value={depTxId} onChange={e => setDepTxId(e.target.value)} />
              </div>
              <div>
                <label className="label">Upload Screenshot</label>
                <input type="file" accept="image/*" onChange={handleSSUpload}
                  style={{ width: '100%', padding: '12px', borderRadius: 12, border: '1.5px dashed #E8590C', background: '#fff8f5', cursor: 'pointer', fontSize: 14 }} />
                {depSS && <div style={{ color: '#27ae60', fontSize: 13, marginTop: 6, fontWeight: 600 }}>✅ Screenshot uploaded</div>}
              </div>
              <button className="btn-orange" onClick={submitProof} disabled={loading}>
                {loading ? <span className="spinner" /> : 'Submit Proof →'}
              </button>
              <button className="btn-ghost" onClick={() => setDepStep(2)}>← Back</button>
            </div>
          )}
        </div>
      )}

      {/* ── WITHDRAW TAB ─────────────────────────────────────────────────── */}
      {tab === 'withdraw' && (
        <div className="page-pad">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
            <button onClick={() => setTab('home')} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#555' }}>←</button>
            <h2 style={{ fontWeight: 800, fontSize: 22 }}>Withdraw to UPI</h2>
          </div>

          {/* Balance */}
          <div style={{ background: '#f5c842', borderRadius: 16, padding: 20, marginBottom: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: '#7a6000', marginBottom: 4 }}>⬡ AVAILABLE BALANCE</div>
            <div style={{ fontWeight: 800, fontSize: 36, color: '#5a4500' }}>{scoins.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
            <div style={{ fontSize: 14, color: '#7a6000', marginTop: 4 }}>≈ ₹{inrVal} INR</div>
          </div>

          {/* Parity card */}
          <div style={{ background: '#fff', border: '1px solid #eee', borderRadius: 14, padding: 16, marginBottom: 20, textAlign: 'center' }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: '#aaa', marginBottom: 8 }}>WITHDRAWAL PARITY</div>
            <div style={{ fontWeight: 700, fontSize: 18, color: '#8a5500' }}>1 SCoin = ₹1 INR</div>
            <div style={{ fontSize: 12, color: '#ccc', marginTop: 4 }}>Minimum: 1,000 SCoins</div>
          </div>

          {err && <div className="error-box">{err}</div>}
          {msg && <div className="success-box">{msg}</div>}

          {/* UPI Setup */}
          <div style={{ marginBottom: 20 }}>
            <label className="label">Your UPI ID</label>
            <input className="input" placeholder="yourname@okaxis"
              value={upiId || user?.upi_id || ''} onChange={e => setUpiId(e.target.value)} style={{ marginBottom: 10 }} />
            <label className="label">Phone Number</label>
            <input className="input" type="tel" placeholder="10-digit mobile number"
              value={phone || user?.phone || ''} onChange={e => setPhone(e.target.value)} style={{ marginBottom: 10 }} />
            <button className="btn-ghost" onClick={saveUpi} disabled={loading} style={{ marginBottom: 16 }}>
              {user?.upi_id ? '✏️ Update UPI & Phone' : '💳 Save UPI & Phone'}
            </button>

            {user?.upi_id && (
              <div style={{ background: '#f5f5f5', borderRadius: 12, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                <span style={{ fontSize: 22 }}>🏛️</span>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{user.upi_id}</div>
                  <div style={{ fontSize: 12, color: '#aaa' }}>Verified • Primary Account</div>
                </div>
                <span style={{ color: '#E8590C', marginLeft: 'auto', fontSize: 20 }}>✅</span>
              </div>
            )}
          </div>

          {/* Amount input */}
          <div style={{ marginBottom: 16 }}>
            <label className="label">Amount to Withdraw (SCoins)</label>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <input className="input" type="number" placeholder="0" min="1000" max={scoins}
                value={wdAmount} onChange={e => setWdAmount(e.target.value)} style={{ fontWeight: 700, fontSize: 20 }} />
              <button onClick={() => setWdAmount(scoins.toString())} style={{ background: '#fdf0e8', color: '#E8590C', border: 'none', borderRadius: 10, padding: '14px 14px', fontWeight: 700, fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap' }}>MAX</button>
            </div>
            {wdAmount > 0 && (
              <div style={{ fontSize: 13, color: '#888', marginTop: 6 }}>
                You will receive: <strong style={{ color: '#27ae60' }}>₹{parseFloat(wdAmount || 0).toFixed(2)}</strong>
              </div>
            )}
          </div>

          <button className="btn-orange" onClick={requestWithdrawal} disabled={loading || !user?.upi_id}>
            {loading ? <span className="spinner" /> : 'Withdraw to UPI →'}
          </button>
          <p style={{ textAlign: 'center', fontSize: 12, color: '#aaa', marginTop: 12 }}>
            Processed within 24 hours. 1 SCoin = ₹1 INR.
          </p>
        </div>
      )}

      {/* ── ACTIVITY TAB ─────────────────────────────────────────────────── */}
      {tab === 'activity' && (
        <div className="page-pad">
          <h2 style={{ fontWeight: 800, fontSize: 22, marginBottom: 20 }}>Activity</h2>
          {transactions.length === 0
            ? <div style={{ textAlign: 'center', color: '#ccc', padding: 48 }}>No transactions yet.</div>
            : transactions.map((tx, i) => <TxRow key={i} tx={tx} />)
          }
        </div>
      )}

      {/* ── PROFILE TAB ──────────────────────────────────────────────────── */}
      {tab === 'profile' && (
        <div className="page-pad">
          <h2 style={{ fontWeight: 800, fontSize: 22, marginBottom: 24 }}>Profile</h2>
          <div style={{ textAlign: 'center', marginBottom: 28 }}>
            <div style={{ width: 72, height: 72, background: '#fdf0e8', borderRadius: 36, margin: '0 auto 12px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32 }}>👤</div>
            <div style={{ fontWeight: 700, fontSize: 18 }}>{user.email}</div>
            <div style={{ fontSize: 13, color: '#aaa', marginTop: 4 }}>
              {user.is_email_verified ? '✅ Email verified' : '⚠️ Email not verified'}
            </div>
          </div>

          {[
            ['💰', 'SCoins Balance', `${scoins.toFixed(2)} SC`],
            ['🎁', 'Referral Code', user.invite_code],
            ['🏛️', 'UPI ID', user.upi_id || 'Not set'],
            ['📱', 'Phone', user.phone || 'Not set'],
            ['📊', 'Total Deposited', `${(user.usdt_deposited || 0).toFixed(2)} USDT`],
            ['💸', 'Referral Earnings', `${(user.referral_bonus || 0).toFixed(2)} SC`],
          ].map(([icon, label, value]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', borderBottom: '1px solid #f5f5f5' }}>
              <span style={{ fontSize: 22 }}>{icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, color: '#aaa', fontWeight: 600 }}>{label}</div>
                <div style={{ fontWeight: 700, marginTop: 2 }}>{value}</div>
              </div>
              {label === 'Referral Code' && (
                <button onClick={() => copyText(user.invite_code, 'Referral code')} style={{ background: '#fdf0e8', color: '#E8590C', border: 'none', borderRadius: 8, padding: '6px 12px', cursor: 'pointer', fontSize: 12, fontWeight: 700 }}>Copy</button>
              )}
            </div>
          ))}

          <button onClick={logout} style={{ width: '100%', marginTop: 28, padding: 16, background: '#fff', border: '2px solid #E8590C', borderRadius: 14, color: '#E8590C', fontWeight: 700, fontSize: 16, cursor: 'pointer' }}>
            Log Out
          </button>
        </div>
      )}

      {/* ── Bottom Navigation ─────────────────────────────────────────────── */}
      <div className="bottom-nav">
        {[
          { key: 'home', icon: '🏠', label: 'HOME' },
          { key: 'deposit', icon: '📥', label: 'DEPOSIT' },
          { key: 'withdraw', icon: '💳', label: 'WITHDRAW' },
          { key: 'activity', icon: '📋', label: 'ACTIVITY' },
          { key: 'profile', icon: '👤', label: 'PROFILE' },
        ].map(n => (
          <button key={n.key} className="nav-item" onClick={() => { if (n.key === 'deposit') resetDeposit(); setTab(n.key); }}>
            <span style={{ fontSize: 20, filter: tab === n.key ? 'none' : 'grayscale(1) opacity(0.4)' }}>{n.icon}</span>
            <span className="nav-label" style={{ color: tab === n.key ? '#E8590C' : '#aaa' }}>{n.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
