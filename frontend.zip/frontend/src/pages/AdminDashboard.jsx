import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import api from '../api';

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = (n) => Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtDate = (s) => s ? new Date(s).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

const S = {
  page:    { minHeight: '100vh', background: '#0f0f0f', color: '#fff', fontFamily: "'Sora', sans-serif" },
  topbar:  { background: '#1a1a1a', padding: '14px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #252525', position: 'sticky', top: 0, zIndex: 50 },
  card:    { background: '#1a1a1a', borderRadius: 14, padding: 20, border: '1px solid #252525' },
  th:      { textAlign: 'left', padding: '12px 14px', fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: '#555', borderBottom: '1px solid #222', whiteSpace: 'nowrap' },
  td:      { padding: '13px 14px', fontSize: 13, borderBottom: '1px solid #1e1e1e', verticalAlign: 'middle' },
  input:   { width: '100%', padding: '11px 14px', borderRadius: 10, border: '1px solid #2a2a2a', background: '#111', color: '#fff', fontFamily: "'Sora', sans-serif", fontSize: 13, outline: 'none', boxSizing: 'border-box' },
};

const badge = (color, label) => (
  <span style={{ background: color + '22', color, padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700, letterSpacing: 0.3, display: 'inline-block' }}>{label}</span>
);

const Btn = ({ children, onClick, color = '#E8590C', disabled = false, small = false }) => (
  <button onClick={onClick} disabled={disabled}
    style={{ background: disabled ? '#333' : color, color: '#fff', border: 'none', borderRadius: 8, padding: small ? '6px 12px' : '8px 16px', fontFamily: "'Sora', sans-serif", fontWeight: 700, fontSize: small ? 12 : 13, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, whiteSpace: 'nowrap' }}>
    {children}
  </button>
);

const StatCard = ({ label, value, color = '#E8590C', icon }) => (
  <div style={{ ...S.card, flex: 1, minWidth: 140 }}>
    <div style={{ fontSize: 20, marginBottom: 8 }}>{icon}</div>
    <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.5, color: '#555', marginBottom: 6 }}>{label}</div>
    <div style={{ fontWeight: 800, fontSize: 24, color }}>{value}</div>
  </div>
);

// ── Image viewer modal ────────────────────────────────────────────────────────
const ImgModal = ({ src, onClose }) => src ? (
  <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.9)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
    <img src={src} alt="screenshot" style={{ maxWidth: '100%', maxHeight: '90vh', borderRadius: 12 }} />
  </div>
) : null;

// ── Main Component ────────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const navigate = useNavigate();
  const [tab, setTab]           = useState('deposits');
  const [stats, setStats]       = useState({});
  const [users, setUsers]       = useState([]);
  const [deposits, setDeposits] = useState([]);
  const [withdrawals, setWds]   = useState([]);
  const [loading, setLoading]   = useState(false);
  const [notes, setNotes]       = useState({});
  const [scAdj, setScAdj]       = useState({});
  const [imgSrc, setImgSrc]     = useState('');
  const [search, setSearch]     = useState('');
  const [depFilter, setDepFilter] = useState('pending');

  const adminApi = useCallback((path, opts = {}) => {
    const token = localStorage.getItem('4m_admin_token');
    if (!token) { navigate('/admin/login'); throw new Error('No token'); }
    return api({ url: path, headers: { Authorization: `Bearer ${token}` }, ...opts });
  }, [navigate]);

  const loadStats = useCallback(async () => {
    try { const r = await adminApi('/admin/stats'); setStats(r.data); } catch {}
  }, [adminApi]);

  const loadDeposits = useCallback(async () => {
    try {
      const r = await adminApi(`/admin/deposits${depFilter ? `?status=${depFilter}` : ''}`);
      setDeposits(r.data.deposits || []);
    } catch {}
  }, [adminApi, depFilter]);

  const loadWithdrawals = useCallback(async () => {
    try {
      const r = await adminApi('/admin/withdrawals?status=pending');
      setWds(r.data.withdrawals || []);
    } catch {}
  }, [adminApi]);

  const loadUsers = useCallback(async () => {
    try { const r = await adminApi('/admin/users'); setUsers(r.data.users || []); } catch {}
  }, [adminApi]);

  useEffect(() => {
    loadStats();
    if (tab === 'deposits')    loadDeposits();
    if (tab === 'withdrawals') loadWithdrawals();
    if (tab === 'users')       loadUsers();
  }, [tab, loadStats, loadDeposits, loadWithdrawals, loadUsers]);

  // Re-load deposits when filter changes
  useEffect(() => { if (tab === 'deposits') loadDeposits(); }, [depFilter, loadDeposits, tab]);

  const do_ = async (fn, successMsg) => {
    setLoading(true);
    try {
      await fn();
      toast.success(successMsg);
      loadStats();
      if (tab === 'deposits')    loadDeposits();
      if (tab === 'withdrawals') loadWithdrawals();
      if (tab === 'users')       loadUsers();
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Action failed.');
    } finally { setLoading(false); }
  };

  const approveDeposit = (id) => do_(
    () => adminApi('/admin/deposit/approve', { method: 'POST', data: { deposit_id: id, admin_notes: notes[id] || '' } }),
    'Deposit approved! SCoins credited to user.'
  );

  const rejectDeposit = (id) => {
    if (!notes[id]) { toast.error('Add a rejection reason first.'); return; }
    do_(
      () => adminApi('/admin/deposit/reject', { method: 'POST', data: { deposit_id: id, admin_notes: notes[id] } }),
      'Deposit rejected.'
    );
  };

  const approveWd = (id) => do_(
    () => adminApi('/admin/withdrawal/approve', { method: 'POST', data: { withdrawal_id: id, admin_notes: notes[id] || '' } }),
    'Withdrawal approved! Send money to user UPI.'
  );

  const rejectWd = (id) => {
    if (!notes[id]) { toast.error('Add a rejection reason first.'); return; }
    do_(
      () => adminApi('/admin/withdrawal/reject', { method: 'POST', data: { withdrawal_id: id, admin_notes: notes[id] } }),
      'Withdrawal rejected. SCoins refunded.'
    );
  };

  const adjustBalance = (userId) => {
    const amt = parseFloat(scAdj[userId]);
    if (!amt) { toast.error('Enter amount first.'); return; }
    do_(
      () => adminApi('/admin/adjust-balance', { method: 'POST', data: { user_id: userId, amount: amt, note: 'Admin adjustment' } }),
      `Balance adjusted by ${amt > 0 ? '+' : ''}${amt} SC`
    );
    setScAdj(p => ({ ...p, [userId]: '' }));
  };

  const banUser = (userId, ban) => do_(
    () => adminApi('/admin/ban-user', { method: 'POST', data: { user_id: userId, ban } }),
    ban ? 'User banned.' : 'User unbanned.'
  );

  const logout = () => {
    localStorage.removeItem('4m_admin_token');
    localStorage.removeItem('4m_admin');
    navigate('/admin/login');
  };

  const filteredUsers = users.filter(u =>
    !search || u.email?.toLowerCase().includes(search.toLowerCase()) || u.invite_code?.toLowerCase().includes(search.toLowerCase())
  );

  const TABS = [
    { key: 'overview',    label: '📊 Overview' },
    { key: 'deposits',    label: `📥 Deposits${stats.pending_deposits ? ` (${stats.pending_deposits})` : ''}` },
    { key: 'withdrawals', label: `💸 Withdrawals${stats.pending_withdrawals ? ` (${stats.pending_withdrawals})` : ''}` },
    { key: 'users',       label: `👥 Users` },
  ];

  return (
    <div style={S.page}>
      <ImgModal src={imgSrc} onClose={() => setImgSrc('')} />

      {/* Top bar */}
      <div style={S.topbar}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 22 }}>🛡️</span>
          <span style={{ fontWeight: 800, fontSize: 17 }}>4Money Admin</span>
          <span style={{ background: '#E8590C22', color: '#E8590C', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 700 }}>CONTROL PANEL</span>
        </div>
        <button onClick={logout} style={{ background: '#2a2a2a', color: '#888', border: 'none', borderRadius: 8, padding: '8px 16px', cursor: 'pointer', fontFamily: "'Sora', sans-serif", fontWeight: 600 }}>Logout</button>
      </div>

      {/* Tab bar */}
      <div style={{ background: '#111', padding: '0 20px', display: 'flex', gap: 2, borderBottom: '1px solid #222', overflowX: 'auto' }}>
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} style={{
            background: 'none', border: 'none', padding: '14px 16px', cursor: 'pointer',
            color: tab === t.key ? '#E8590C' : '#555', fontWeight: 700, fontSize: 13,
            fontFamily: "'Sora', sans-serif", whiteSpace: 'nowrap',
            borderBottom: `2px solid ${tab === t.key ? '#E8590C' : 'transparent'}`,
          }}>{t.label}</button>
        ))}
      </div>

      <div style={{ padding: 20 }}>

        {/* ── OVERVIEW ─────────────────────────────────────────────────── */}
        {tab === 'overview' && (
          <>
            <h2 style={{ margin: '0 0 20px', fontWeight: 800, fontSize: 20 }}>Platform Overview</h2>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 24 }}>
              <StatCard icon="👥" label="TOTAL USERS"       value={stats.total_users || 0}        color="#fff" />
              <StatCard icon="⏳" label="PENDING DEPOSITS"  value={stats.pending_deposits || 0}    color="#f59e0b" />
              <StatCard icon="✅" label="APPROVED DEPOSITS" value={stats.approved_deposits || 0}   color="#22c55e" />
              <StatCard icon="💸" label="PENDING WITHDRAWALS" value={stats.pending_withdrawals || 0} color="#f59e0b" />
              <StatCard icon="🪙" label="TOTAL SC ISSUED"   value={fmt(stats.total_scoins_issued)} color="#E8590C" />
              <StatCard icon="💵" label="TOTAL USDT IN"     value={`$${fmt(stats.total_usdt_received)}`} color="#22c55e" />
            </div>
            <div style={{ ...S.card }}>
              <h3 style={{ margin: '0 0 12px', fontWeight: 700 }}>Quick Actions</h3>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <Btn onClick={() => setTab('deposits')}>Review Pending Deposits</Btn>
                <Btn onClick={() => setTab('withdrawals')} color="#7c3aed">Process Withdrawals</Btn>
                <Btn onClick={() => setTab('users')} color="#0ea5e9">Manage Users</Btn>
              </div>
            </div>
          </>
        )}

        {/* ── DEPOSITS ─────────────────────────────────────────────────── */}
        {tab === 'deposits' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
              <h2 style={{ margin: 0, fontWeight: 800, fontSize: 20 }}>Deposits</h2>
              <div style={{ display: 'flex', gap: 8 }}>
                {['pending', 'approved', 'rejected', ''].map(f => (
                  <button key={f} onClick={() => setDepFilter(f)} style={{
                    background: depFilter === f ? '#E8590C' : '#2a2a2a',
                    color: '#fff', border: 'none', borderRadius: 8, padding: '7px 14px',
                    fontFamily: "'Sora', sans-serif", fontWeight: 600, fontSize: 12, cursor: 'pointer'
                  }}>{f || 'All'}</button>
                ))}
                <Btn onClick={loadDeposits} color="#333" small>↻ Refresh</Btn>
              </div>
            </div>

            {deposits.length === 0
              ? <div style={{ ...S.card, textAlign: 'center', color: '#444', padding: 48 }}>No deposits found.</div>
              : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  {deposits.map(dep => (
                    <div key={dep.id} style={{ ...S.card }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 15 }}>{dep.user_email}</div>
                          <div style={{ fontSize: 12, color: '#555', marginTop: 3 }}>{fmtDate(dep.created_at)}</div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontWeight: 800, fontSize: 18, color: '#E8590C' }}>{dep.usdt_amount} USDT</div>
                          <div style={{ fontSize: 13, color: '#888' }}>= {fmt(dep.sc_amount)} SC</div>
                        </div>
                      </div>

                      {/* Details grid */}
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
                        {[
                          ['Status', dep.status === 'approved' ? badge('#22c55e', 'APPROVED') : dep.status === 'rejected' ? badge('#ef4444', 'REJECTED') : badge('#f59e0b', 'PENDING')],
                          ['OTP Verified', dep.otp_verified ? badge('#22c55e', 'YES') : badge('#ef4444', 'NO')],
                          ['TX ID', dep.transaction_id ? <span style={{ fontFamily: 'monospace', fontSize: 11, color: '#aaa', wordBreak: 'break-all' }}>{dep.transaction_id}</span> : <span style={{ color: '#555' }}>—</span>],
                          ['Admin Notes', <span style={{ color: '#aaa', fontSize: 12 }}>{dep.admin_notes || '—'}</span>],
                        ].map(([label, val]) => (
                          <div key={label} style={{ background: '#111', borderRadius: 8, padding: '10px 12px' }}>
                            <div style={{ fontSize: 10, color: '#555', fontWeight: 700, letterSpacing: 1, marginBottom: 4 }}>{label}</div>
                            <div>{val}</div>
                          </div>
                        ))}
                      </div>

                      {/* Screenshot */}
                      {dep.screenshot_base64 && (
                        <button onClick={() => setImgSrc(dep.screenshot_base64)}
                          style={{ background: '#0ea5e922', color: '#0ea5e9', border: 'none', borderRadius: 8, padding: '8px 14px', cursor: 'pointer', fontFamily: "'Sora', sans-serif", fontWeight: 700, fontSize: 12, marginBottom: 14, display: 'block' }}>
                          🖼️ View Screenshot
                        </button>
                      )}

                      {/* Actions (only for pending) */}
                      {dep.status === 'pending' && (
                        <div>
                          <input value={notes[dep.id] || ''} onChange={e => setNotes(p => ({ ...p, [dep.id]: e.target.value }))}
                            placeholder="Admin notes (required for rejection)"
                            style={{ ...S.input, marginBottom: 10 }} />
                          <div style={{ display: 'flex', gap: 10 }}>
                            <Btn onClick={() => approveDeposit(dep.id)} disabled={loading} color="#22c55e">
                              ✓ Approve & Credit
                            </Btn>
                            <Btn onClick={() => rejectDeposit(dep.id)} disabled={loading} color="#ef4444">
                              ✕ Reject
                            </Btn>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )
            }
          </>
        )}

        {/* ── WITHDRAWALS ──────────────────────────────────────────────── */}
        {tab === 'withdrawals' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h2 style={{ margin: 0, fontWeight: 800, fontSize: 20 }}>Withdrawal Requests</h2>
              <Btn onClick={loadWithdrawals} color="#333" small>↻ Refresh</Btn>
            </div>

            {withdrawals.length === 0
              ? <div style={{ ...S.card, textAlign: 'center', color: '#444', padding: 48 }}>No pending withdrawals. 🎉</div>
              : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  {withdrawals.map(wd => (
                    <div key={wd.id} style={{ ...S.card }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 15 }}>{wd.user_email}</div>
                          <div style={{ fontSize: 12, color: '#555', marginTop: 3 }}>{fmtDate(wd.created_at)}</div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontWeight: 800, fontSize: 20, color: '#f59e0b' }}>{fmt(wd.sc_amount)} SC</div>
                          <div style={{ fontSize: 14, color: '#22c55e', fontWeight: 700 }}>= ₹{fmt(wd.inr_amount)}</div>
                        </div>
                      </div>

                      {/* UPI info — the most important part */}
                      <div style={{ background: '#0f2a0f', border: '1px solid #22c55e33', borderRadius: 10, padding: '14px 16px', marginBottom: 14 }}>
                        <div style={{ fontSize: 10, color: '#22c55e', fontWeight: 700, letterSpacing: 1.5, marginBottom: 6 }}>SEND PAYMENT TO</div>
                        <div style={{ fontWeight: 800, fontSize: 18, color: '#fff' }}>{wd.upi_id}</div>
                        <div style={{ fontSize: 13, color: '#22c55e', fontWeight: 700, marginTop: 4 }}>Amount: ₹{fmt(wd.inr_amount)}</div>
                      </div>

                      <input value={notes[wd.id] || ''} onChange={e => setNotes(p => ({ ...p, [wd.id]: e.target.value }))}
                        placeholder="Notes (required for rejection)"
                        style={{ ...S.input, marginBottom: 10 }} />
                      <div style={{ display: 'flex', gap: 10 }}>
                        <Btn onClick={() => approveWd(wd.id)} disabled={loading} color="#22c55e">
                          ✓ Mark as Paid
                        </Btn>
                        <Btn onClick={() => rejectWd(wd.id)} disabled={loading} color="#ef4444">
                          ✕ Reject & Refund
                        </Btn>
                      </div>
                    </div>
                  ))}
                </div>
              )
            }
          </>
        )}

        {/* ── USERS ────────────────────────────────────────────────────── */}
        {tab === 'users' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
              <h2 style={{ margin: 0, fontWeight: 800, fontSize: 20 }}>Users ({users.length})</h2>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Search by email or invite code..."
                style={{ ...S.input, width: 280 }} />
            </div>

            {filteredUsers.length === 0
              ? <div style={{ ...S.card, textAlign: 'center', color: '#444', padding: 48 }}>No users found.</div>
              : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {filteredUsers.map(u => (
                    <div key={u.id} style={{ ...S.card }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                            <span style={{ fontWeight: 700, fontSize: 15 }}>{u.email}</span>
                            {u.is_banned && badge('#ef4444', 'BANNED')}
                          </div>
                          <div style={{ fontSize: 12, color: '#555' }}>
                            Joined {fmtDate(u.created_at)} &nbsp;|&nbsp; Code: <span style={{ color: '#E8590C', fontWeight: 700 }}>{u.invite_code}</span>
                          </div>
                          {u.upi_id && <div style={{ fontSize: 12, color: '#22c55e', marginTop: 3 }}>UPI: {u.upi_id}</div>}
                          {u.phone  && <div style={{ fontSize: 12, color: '#888' }}>📱 {u.phone}</div>}
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontWeight: 800, fontSize: 20, color: '#E8590C' }}>{fmt(u.scoins)} SC</div>
                          <div style={{ fontSize: 13, color: '#888' }}>= ₹{fmt(u.scoins)}</div>
                          <div style={{ fontSize: 12, color: '#555', marginTop: 2 }}>Deposited: ${fmt(u.usdt_deposited)} USDT</div>
                        </div>
                      </div>

                      {/* Balance adjustment */}
                      <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                        <input type="number" value={scAdj[u.id] || ''} onChange={e => setScAdj(p => ({ ...p, [u.id]: e.target.value }))}
                          placeholder="SC amount (use - to deduct)"
                          style={{ ...S.input }} />
                        <Btn onClick={() => adjustBalance(u.id)} disabled={loading} color="#7c3aed" small>
                          Adjust SC
                        </Btn>
                      </div>

                      {/* Ban / Unban */}
                      <Btn onClick={() => banUser(u.id, !u.is_banned)} color={u.is_banned ? '#22c55e' : '#ef4444'} small>
                        {u.is_banned ? '✓ Unban User' : '⊘ Ban User'}
                      </Btn>
                    </div>
                  ))}
                </div>
              )
            }
          </>
        )}
      </div>
    </div>
  );
}
