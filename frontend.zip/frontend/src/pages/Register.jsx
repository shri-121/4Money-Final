import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import api from '../api';

const Logo = () => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
    <div style={{ width: 40, height: 40, background: '#E8590C', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <span style={{ color: '#fff', fontSize: 20 }}>💰</span>
    </div>
    <span style={{ fontWeight: 800, fontSize: 22, color: '#1a1a1a' }}>4Money</span>
  </div>
);

export default function Register() {
  const navigate = useNavigate();
  const [step, setStep]           = useState(1);
  const [email, setEmail]         = useState('');
  const [otp, setOtp]             = useState('');
  const [password, setPassword]   = useState('');
  const [confirm, setConfirm]     = useState('');
  const [invite, setInvite]       = useState('');
  const [loading, setLoading]     = useState(false);
  const [devOtp, setDevOtp]       = useState('');
  const [err, setErr]             = useState('');

  const go = async (fn) => {
    setErr(''); setLoading(true);
    try { await fn(); }
    catch (e) { setErr(e.response?.data?.detail || 'Something went wrong.'); }
    finally { setLoading(false); }
  };

  const sendOtp = () => go(async () => {
    const r = await api.post('/auth/send-otp', { email, purpose: 'registration' });
    if (r.data.dev_otp) { setDevOtp(r.data.dev_otp); toast.info(`Dev OTP: ${r.data.dev_otp}`); }
    else toast.success('OTP sent to your email!');
    setStep(2);
  });

  const verifyOtp = () => go(async () => {
    await api.post('/auth/verify-otp', { email, otp_code: otp, purpose: 'registration' });
    toast.success('Email verified!');
    setStep(3);
  });

  const register = () => go(async () => {
    if (password !== confirm) { setErr('Passwords do not match.'); return; }
    if (password.length < 6) { setErr('Password must be at least 6 characters.'); return; }
    const r = await api.post('/auth/register', { email, password, invite_code: invite || null });
    localStorage.setItem('4m_token', r.data.token);
    localStorage.setItem('4m_user', JSON.stringify(r.data.user));
    toast.success('Account created! Welcome to 4Money 🎉');
    navigate('/dashboard');
  });

  const steps = ['Email', 'Verify', 'Password'];

  return (
    <div style={{ minHeight: '100vh', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 420 }}>
        <Logo />

        {/* Step indicator */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 32 }}>
          {steps.map((s, i) => (
            <div key={s} style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ height: 3, borderRadius: 2, background: i + 1 <= step ? '#E8590C' : '#eee' }} />
              <span style={{ fontSize: 11, fontWeight: 700, color: i + 1 <= step ? '#E8590C' : '#ccc', letterSpacing: 0.5 }}>{s}</span>
            </div>
          ))}
        </div>

        <h2 style={{ fontWeight: 800, fontSize: 26, marginBottom: 6 }}>
          {step === 1 ? 'Create Account' : step === 2 ? 'Verify Email' : 'Set Password'}
        </h2>
        <p style={{ color: '#888', fontSize: 14, marginBottom: 28 }}>
          {step === 1 ? 'Join the 4Money ecosystem today.' :
           step === 2 ? `Enter the code sent to ${email}` :
           'Choose a secure password.'}
        </p>

        {err && <div className="error-box">{err}</div>}

        {step === 1 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <label className="label">Email Address</label>
              <input className="input" type="email" placeholder="you@example.com"
                value={email} onChange={e => setEmail(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendOtp()} />
            </div>
            <div>
              <label className="label">Invite Code (Optional)</label>
              <input className="input" placeholder="XXXXXXXX"
                value={invite} onChange={e => setInvite(e.target.value.toUpperCase())} />
            </div>
            <button className="btn-orange" onClick={sendOtp} disabled={!email || loading}>
              {loading ? <span className="spinner" /> : 'Send Verification Code →'}
            </button>
          </div>
        )}

        {step === 2 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {devOtp && (
              <div style={{ background: '#fff8e1', border: '1px solid #ffc107', borderRadius: 10, padding: '12px 16px', textAlign: 'center' }}>
                <span style={{ fontSize: 12, color: '#8a6d00' }}>Dev mode OTP: </span>
                <strong style={{ color: '#E8590C', fontSize: 18, letterSpacing: 4 }}>{devOtp}</strong>
              </div>
            )}
            <div>
              <label className="label">6-Digit Code</label>
              <input className="input" type="text" placeholder="000000" maxLength={6}
                value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, ''))}
                style={{ fontSize: 24, fontWeight: 700, letterSpacing: 8, textAlign: 'center' }}
                onKeyDown={e => e.key === 'Enter' && verifyOtp()} />
            </div>
            <button className="btn-orange" onClick={verifyOtp} disabled={otp.length !== 6 || loading}>
              {loading ? <span className="spinner" /> : 'Verify Email →'}
            </button>
            <button className="btn-ghost" onClick={() => { setStep(1); setOtp(''); setDevOtp(''); }}>
              ← Change Email
            </button>
          </div>
        )}

        {step === 3 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <label className="label">Password</label>
              <input className="input" type="password" placeholder="Min 6 characters"
                value={password} onChange={e => setPassword(e.target.value)} />
            </div>
            <div>
              <label className="label">Confirm Password</label>
              <input className="input" type="password" placeholder="Re-enter password"
                value={confirm} onChange={e => setConfirm(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && register()} />
            </div>
            <button className="btn-orange" onClick={register} disabled={!password || !confirm || loading}>
              {loading ? <span className="spinner" /> : 'Create Account →'}
            </button>
          </div>
        )}

        <p style={{ textAlign: 'center', marginTop: 24, color: '#888', fontSize: 14 }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: '#E8590C', fontWeight: 700, textDecoration: 'none' }}>Login</Link>
        </p>
      </div>
    </div>
  );
}
