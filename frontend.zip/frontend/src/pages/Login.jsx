import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import api from '../api';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [err, setErr]         = useState('');

  const login = async () => {
    setErr(''); setLoading(true);
    try {
      const r = await api.post('/auth/login', { email, password });
      localStorage.setItem('4m_token', r.data.token);
      localStorage.setItem('4m_user', JSON.stringify(r.data.user));
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (e) {
      setErr(e.response?.data?.detail || 'Login failed.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 420 }}>
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ width: 56, height: 56, background: '#E8590C', borderRadius: 16, margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ fontSize: 28 }}>💰</span>
          </div>
          <h1 style={{ fontWeight: 800, fontSize: 28, marginBottom: 6 }}>Sign In</h1>
          <p style={{ color: '#888', fontSize: 14 }}>Access your 4Money account</p>
        </div>

        <div style={{ background: '#fff', borderRadius: 20, padding: 28, boxShadow: '0 4px 24px rgba(0,0,0,0.08)', border: '1px solid #eee' }}>
          {err && <div className="error-box">{err}</div>}
          <div style={{ marginBottom: 16 }}>
            <label className="label">Email Address</label>
            <input className="input" type="email" placeholder="you@example.com"
              value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div style={{ marginBottom: 24 }}>
            <label className="label">Password</label>
            <input className="input" type="password" placeholder="Your password"
              value={password} onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && login()} />
          </div>
          <button className="btn-orange" onClick={login} disabled={!email || !password || loading}>
            {loading ? <span className="spinner" /> : 'Login →'}
          </button>
        </div>

        <p style={{ textAlign: 'center', marginTop: 24, color: '#888', fontSize: 14 }}>
          New to 4Money?{' '}
          <Link to="/register" style={{ color: '#E8590C', fontWeight: 700, textDecoration: 'none' }}>Create Account</Link>
        </p>
        <p style={{ textAlign: 'center', marginTop: 8, fontSize: 13 }}>
          <Link to="/admin/login" style={{ color: '#aaa', textDecoration: 'none' }}>Admin Login</Link>
        </p>
      </div>
    </div>
  );
}
