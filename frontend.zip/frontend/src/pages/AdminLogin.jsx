import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import api from '../api';

export default function AdminLogin() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [err, setErr]           = useState('');

  const login = async () => {
    setErr(''); setLoading(true);
    try {
      const r = await api.post('/admin/login', { username, password });
      localStorage.setItem('4m_admin_token', r.data.token);
      localStorage.setItem('4m_admin', JSON.stringify(r.data.admin));
      toast.success('Welcome, Admin!');
      navigate('/admin/dashboard');
    } catch (e) {
      setErr(e.response?.data?.detail || 'Invalid credentials.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0f0f0f', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, fontFamily: "'Sora', sans-serif" }}>
      <div style={{ width: '100%', maxWidth: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{ width: 64, height: 64, background: '#E8590C', borderRadius: 18, margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30 }}>🛡️</div>
          <h1 style={{ color: '#fff', fontWeight: 800, fontSize: 26, margin: '0 0 6px' }}>Admin Panel</h1>
          <p style={{ color: '#555', fontSize: 14 }}>4Money Control Center</p>
        </div>

        <div style={{ background: '#1a1a1a', borderRadius: 20, padding: 28, border: '1px solid #2a2a2a' }}>
          {err && (
            <div style={{ background: '#2a0000', color: '#ff6b6b', padding: '12px 16px', borderRadius: 10, fontSize: 13, marginBottom: 16 }}>{err}</div>
          )}
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: '#666', marginBottom: 8 }}>USERNAME</label>
            <input value={username} onChange={e => setUsername(e.target.value)}
              placeholder="admin"
              style={{ width: '100%', padding: '14px 16px', borderRadius: 12, border: '1.5px solid #2a2a2a', background: '#111', color: '#fff', fontSize: 15, outline: 'none', boxSizing: 'border-box', fontFamily: "'Sora', sans-serif" }} />
          </div>
          <div style={{ marginBottom: 24 }}>
            <label style={{ display: 'block', fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: '#666', marginBottom: 8 }}>PASSWORD</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              onKeyDown={e => e.key === 'Enter' && login()}
              style={{ width: '100%', padding: '14px 16px', borderRadius: 12, border: '1.5px solid #2a2a2a', background: '#111', color: '#fff', fontSize: 15, outline: 'none', boxSizing: 'border-box', fontFamily: "'Sora', sans-serif" }} />
          </div>
          <button onClick={login} disabled={!username || !password || loading}
            style={{ width: '100%', padding: 15, background: loading ? '#555' : '#E8590C', color: '#fff', border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer', fontFamily: "'Sora', sans-serif" }}>
            {loading ? 'Logging in...' : 'Enter Admin Panel →'}
          </button>
        </div>

        <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13 }}>
          <Link to="/login" style={{ color: '#555', textDecoration: 'none' }}>← Back to User Login</Link>
        </p>
      </div>
    </div>
  );
}
