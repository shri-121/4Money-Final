import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import Register from './pages/Register';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';

const ProtectedUser = ({ children }) => {
  const token = localStorage.getItem('4m_token');
  return token ? children : <Navigate to="/login" replace />;
};
const ProtectedAdmin = ({ children }) => {
  const token = localStorage.getItem('4m_admin_token');
  return token ? children : <Navigate to="/admin/login" replace />;
};

export default function App() {
  return (
    <>
      <Toaster position="top-center" richColors duration={3000} />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/register" replace />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<ProtectedUser><Dashboard /></ProtectedUser>} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<ProtectedAdmin><AdminDashboard /></ProtectedAdmin>} />
        </Routes>
      </BrowserRouter>
    </>
  );
}
